<?php
// Database connection
$host = "localhost";
$username = "root";
$password = "";
$database = "buspass_db";

$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Sanitize user input to prevent SQL injection
    $username = mysqli_real_escape_string($conn, $username);

    // Query to fetch user from database
    $query = "SELECT * FROM users WHERE username='$username'";
    $result = $conn->query($query);

    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
        if (password_verify($password, $row['password'])) {
           
            $message = "User logged in Successfully.";
            echo "<script>alert('$message');</script>";
            echo "<script>setTimeout(function() { window.location.href = 'user_dashboard.html'; }, 1500);</script>";
            
           
        } else {
            $message = "Register First Then Login.";
            echo "<script>alert('$message');</script>";
            echo "<script>setTimeout(function() { window.location.href = 'user_login.html'; }, 1500);</script>";
        }
    } 
}
?>
 