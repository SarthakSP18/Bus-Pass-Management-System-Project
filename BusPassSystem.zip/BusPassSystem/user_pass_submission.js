// user_pass_submission.js
$(document).ready(function() {
    $('#passSubmissionForm').submit(function(event) {
        event.preventDefault(); // Prevent form submission

        // Capture form data
        var formData = {
            fullname: $('#fullname').val(),
            photo: $('#photo').val(),
            phone_no: $('#phoneno').val(),
            gender: $('#gender').val(),
            email: $('#email').val(),
            id_type: $('#id_type').val(),
            id_card_no: $('#id_card_no').val(),
            bonafide: $('#bonafide').val(),
            fromdate: $('#fromdate').val(),
            todate: $('#todate').val(),
            validity: $('#validity').val(),
            from_dest: $('#from_dest').val(),
            to_dest: $('#to_dest').val(),
            cost: $('#cost').val(),
        };

        // Send data to server using AJAX
        $.ajax({
            type: 'POST',
            url: 'pass.php',
            data: formData,
            success: function(response) {
                alert(response); // Display response message
            }
        });
    });
});