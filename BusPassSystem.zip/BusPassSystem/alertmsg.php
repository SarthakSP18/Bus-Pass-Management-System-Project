<?php

$message = "Pass request submitted successfully!";
echo "<script>alert('$message');</script>";
?>
