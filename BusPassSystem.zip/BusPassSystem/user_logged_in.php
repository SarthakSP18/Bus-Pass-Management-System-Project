// user_logged_in.php
<?php
// Assuming the user is logged in and their ID is stored in a session variable
session_start();
if (!isset($_SESSION['id'])) {
    // Redirect to login page if user is not logged in
    header("Location: user_register.html");
    exit();
}

// Retrieve user's pass information from the database
$userId = $_SESSION['id'];
// Assuming you have established a database connection
$mysqli = new mysqli("localhost", "root", "", "buspass_db");
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}
$sql = "SELECT * FROM tbluser WHERE id = ?";
$stmt = $mysqli->prepare($sql);
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();
$pass = $result->fetch_assoc();
$stmt->close();
$mysqli->close();

// Display the pass information on the user's page
if ($pass) {
    
    echo "Pass Number: " . $pass['passnumber'] . "<br>";
    echo "Full Name: " . $pass['fullname'] . "<br>";
    echo "Photo: " . $pass['photo'] . "<br>";
    echo "Mobile Number: " . $pass['phone'] . "<br>";
    echo "Email: " . $pass['email'] . "<br>";
    echo "Identity Type: " . $pass['id_type'] . "<br>";
    echo "ID Card Number: " . $pass['id_card_no'] . "<br>";
    echo "From Destination: " . $pass['from_dest'] . "<br>";
    echo "To Destination: " . $pass['to_dest'] . "<br>";
    echo "From Date " . $pass['fromdate'] . "<br>";
    echo "To Date" . $pass['todate'] . "<br>";
    echo "Cost " . $pass['cost'] . "<br>";
    echo "Pass Creation Date " . $pass['created_at'] . "<br>";
   
   
    // Display other pass details as needed
} else {
    echo "<p>No bus pass found.</p>";
}
?>
