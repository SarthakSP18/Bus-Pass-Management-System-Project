<?php
require_once('tcpdf/tcpdf.php');

// Define constants for PDF header
// define('PDF_HEADER_LOGO', 'logoimage.jpg');
define('PDF_HEADER_LOGO_WIDTH', 30);
define('PDF_HEADER_TITLE', 'BUS PASS');
define('PDF_HEADER_STRING', 'bus pass');

// Define constants for PDF margins
define('PDF_MARGIN_LEFT', 15);
define('PDF_MARGIN_TOP', 15);
define('PDF_MARGIN_RIGHT', 15);
define('PDF_MARGIN_HEADER', 5);
define('PDF_MARGIN_FOOTER', 10);

// Define constant for PDF font
define('PDF_FONT_MONOSPACED', 'courier');

// Create new PDF document
$pdf = new TCPDF('P', 'mm', 'A4', true, 'UTF-8', false);

// Set document information
$pdf->SetCreator(PDF_CREATOR);
$pdf->SetAuthor('BPMSystem');
$pdf->SetTitle('Bus Pass');
$pdf->SetSubject('Bus Pass');
$pdf->SetKeywords('Bus Pass, TCPDF, PHP');

// Set default header data
$pdf->SetHeaderData( PDF_HEADER_LOGO_WIDTH, PDF_HEADER_TITLE.' 001', PDF_HEADER_STRING);

// Set header and footer fonts
$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));

// Set default monospaced font
$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

// Set margins
$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);

// Set auto page breaks
$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);

// Set image scale factor
$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);

// Add a page
$pdf->AddPage();

// Set font
$pdf->SetFont('helvetica', '', 12);

// Populate PDF with user's information
$pdf->Write(0, 'Pass Number: ' . $passnum . "\n");
$pdf->Write(0, 'Full Name: ' . $fullname . "\n");
$pdf->Write(0, 'Photo: ' . $photo . "\n");
$pdf->Write(0, 'Phone Number: ' . $phone_no . "\n");
$pdf->Write(0, 'ID type: ' . $id_type . "\n");
$pdf->Write(0, 'Id Card number: ' . $id_card_no . "\n");
$pdf->Write(0, 'From Destination: ' . $from_dest . "\n");
$pdf->Write(0, 'To Destination: ' . $to_dest . "\n");
$pdf->Write(0, 'From Date: ' . $fromdate . "\n");
$pdf->Write(0, 'To Date: ' . $todate . "\n");
$pdf->Write(0, 'Cost: ' . $cost . "\n");

// Output PDF to browser
$pdf->Output('bus_pass.pdf', 'D');

// Close and exit
$pdf->Close();
exit;
?>
