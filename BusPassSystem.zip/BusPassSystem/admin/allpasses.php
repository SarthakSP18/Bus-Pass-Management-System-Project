<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "buspass_db";

$mysqli = new mysqli($servername, $username, $password, $dbname);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>All Passes</title>
    <link rel="stylesheet" href="allpasses.css"> 
</head>
<body>
    <h1>All Passes</h1>
    <table>
        <thead>
            <tr>
                <th>S.No</th>
                <th>Pass Number</th>
                <th>Full Name</th>
                <th>Contact Number</th>
                <th>Email</th>
                <th>Id_Type</th>
                <th>Id_Card_NO</th>
                <th>From Date</th>
                <th>To Date</th>
                <th>From Destination</th>
                <th>To Destination</th>
                <th>Cost</th>
                <th>Pass Status</th>
                <th>Creation Date</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $sql = "SELECT * FROM tbluser";
            $query = $mysqli->query($sql);
            $cnt = 1;
            while ($row = $query->fetch_assoc()) {
            ?>
            <tr>
                <td><?php echo $cnt; ?></td>
                <td><?php echo $row['passnumber']; ?></td>
                <td><?php echo $row['fullname']; ?></td>
                <td><?php echo $row['phone_no']; ?></td>
                <td><?php echo $row['email']; ?></td>
                <td><?php echo $row['id_type']; ?></td>

                <td><?php echo $row['id_card_no']; ?></td>

                <td><?php echo $row['fromdate']; ?></td>
              <td><?php echo $row['todate']; ?></td>
      <td><?php echo $row['from_dest']; ?></td>
                <td><?php echo $row['to_dest']; ?></td>
                <td><?php echo $row['cost']; ?></td>
                <td><?php echo $row['pass_status']; ?></td>
              <td><?php echo $row['created_at']; ?></td>
            </tr>
            <?php $cnt++; } ?>
        </tbody>
    </table>
</body>
</html>
