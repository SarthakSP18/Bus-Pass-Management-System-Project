<?php
// Database connection
$servername = "localhost";
$username = "root"; 
$password = ""; 
$dbname = "buspass_db";

$mysqli = new mysqli($servername, $username, $password, $dbname);

if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

$sql = "SELECT * FROM tbluser WHERE pass_status = 'Pending'";
$result = $mysqli->query($sql);

if ($result->num_rows > 0) {
    echo "<table>";
    echo "<tr><th>Pass Number</th><th>Full Name</th><th>Mobile Number</th><th>Identity Type</th><th>Id Number</th><th>From Date</th><th>To Date</th><th>Validity</th><th>FromDest</th><th>ToDest</th><th>Cost</th><th>Created At</th><th>Actions</th></tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row['passnumber'] . "</td>";
        echo "<td>" . $row['fullname'] . "</td>";
        echo "<td>" . $row['phone_no'] . "</td>";
        echo "<td>" . $row['id_type'] . "</td>";
        echo "<td>" . $row['id_card_no'] . "</td>";
        echo "<td>" . $row['fromdate'] . "</td>";
        echo "<td>" . $row['todate'] . "</td>";
        echo "<td>" . $row['validity'] . "</td>";
        echo "<td>" . $row['from_dest'] . "</td>";
        echo "<td>" . $row['to_dest'] . "</td>";
        echo "<td>" . $row['cost'] . "</td>";
        echo "<td>" . $row['created_at'] . "</td>";
        echo "<td><button onclick='acceptPass(" . $row['passnumber'] . ")'>Accept</button></td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "No pending pass requests found.";
}

$mysqli->close();
?>
