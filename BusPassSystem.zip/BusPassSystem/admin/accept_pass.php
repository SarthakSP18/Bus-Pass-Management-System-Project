<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "buspass_db";

$mysqli = new mysqli($servername, $username, $password, $dbname);

// Check for database connection errors
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

// Function to generate PDF pass
function generatePDFPass($passId) {
    require_once('tcpdf/tcpdf.php');
    $pdf = new TCPDF();
    $pdf->AddPage();
    $pdf->SetFont('Arial', 'B', 12);
    $pdf->Cell(0, 10, 'Pass ID: ' . $passId, 0, 1);
    $pdfContent = $pdf->Output('', 'S');
    return $pdfContent;
}
if (isset($_POST['passId'])) {
    $passId = $_POST['passId'];

    $sql = "UPDATE tbluser SET pass_status = 'Accepted' WHERE passnumber = ?";
    $stmt = $mysqli->prepare($sql);

    if (!$stmt) {
        // Error preparing SQL statement
        echo "Error preparing SQL statement: " . $mysqli->error;
    } else {
        $stmt->bind_param("i", $passId);

        if ($stmt->execute()) {
           
            $message = "Pass Request accepted.";
            echo "<script>alert('$message');</script>";
            echo "<script>setTimeout(function() { window.location.href = 'pass_enquiry.html'; }, 1000);</script>";
        } else {
            // Error executing the update query
            echo "Error accepting pass: " . $stmt->error;
        }

        // Close the prepared statement
        $stmt->close();
    }
} else {
    // 'passId' is not set in $_POST
    echo "Pass ID not provided.";
}


// Close the database connection
$mysqli->close();
?>
