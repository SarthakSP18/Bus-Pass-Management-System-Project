<?php
session_start();

// Database connection
$host = "localhost";
$username = "root";
$password = "";
$database = "buspass_db";

$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $inputUsername = $_POST['username'];
    $inputPassword = $_POST['password'];

    // Prepare and execute SQL query to retrieve the admin's password from the database
    $sql = "SELECT password FROM admin WHERE username = 'admin'|| 'admin2'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Fetch the password hash from the result
        $row = $result->fetch_assoc();
        $adminPasswordHash = $row['password'];

        // Verify the password using password_verify function
        if (password_verify($inputPassword, $adminPasswordHash)) {
           
            $_SESSION['admin_logged_in'] = true;
            $message = "Admin logged in Successfully.";
            echo "<script>alert('$message');</script>";
            echo "<script>setTimeout(function() { window.location.href = 'admindashboard.html'; }, 1500);</script>";
            exit();
        } else {
            $error_message = 'Invalid username or password.';
            echo "<script>alert('$error_message');</script>";
            echo "<script>setTimeout(function() { window.location.href = 'adminlogin.html'; }, 1500);</script>";
        }
    } else {
        $error_message = 'Invalid username or password.';
    }
}

$conn->close();
?>
