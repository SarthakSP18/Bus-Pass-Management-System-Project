<!-- <?php
$servername = "localhost";
$username = "root"; 
$password = ""; 
$dbname = "buspass_db";
$mysqli = new mysqli("localhost", "root", "", "buspass_db");

// Check connection
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

// Check if passId is set in $_POST
if(isset($_POST['passId'])) {
    // Get pass ID from POST data
    $passId = $_POST['passId'];

    // Query to retrieve pass details
    $sql = "SELECT * FROM tbluser WHERE id = ?";
    $stmt = $mysqli->prepare($sql);
    $stmt->bind_param("i", $passId);

    // Execute the prepared statement
    if ($stmt->execute()) {
        // Get the result
        $result = $stmt->get_result();
        
        // Check if pass details were found
        if ($result->num_rows > 0) {
            // Fetch pass details
            $pass = $result->fetch_assoc();
            
            // Output pass details as JSON
            echo json_encode($pass);
        } else {
            echo "Pass not found.";
        }
    } else {
        echo "Error executing SQL query: " . $mysqli->error;
    }

    // Close the statement
    $stmt->close();
} else {
    echo "Pass ID not provided.";
}

// Close the database connection
$mysqli->close();
?> -->
