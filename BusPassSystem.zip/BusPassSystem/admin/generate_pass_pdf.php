<?php
require_once('tcpdf/tcpdf.php');

function generatePDFPass($passnumber, $fullname, $photo, $phone_no, $email, $gender, $id_type, $id_card_no, $from_dest, $to_dest, $fromdate, $todate, $cost) {
    // Create new PDF document
    $pdf = new TCPDF('P', 'mm', 'A4', true, 'UTF-8', false);

    // Set document information
    $pdf->SetCreator('Bus Pass Management System');
    $pdf->SetAuthor('Admin');
    $pdf->SetTitle('Bus Pass');
    $pdf->SetSubject('Bus Pass');

    // Add a page
    $pdf->AddPage();

    // Set font
    $pdf->SetFont('helvetica', '', 12);

    // Add pass details to the PDF
    $pdf->Write(0, 'Pass Number: ' . $passnumber);
    $pdf->Ln();
    $pdf->Write(0, 'Full Name: ' . $fullname);
    $pdf->Ln();
    
    $pdf->Write(0, 'Photo:');
    $pdf->Image($photo, 10, 40, 50, 50, '', '', '', false, 300, '', false, false, 0);
    $pdf->Ln();
    $pdf->Write(0, 'Mobile Number: ' . $phone_no);
    $pdf->Ln();
    $pdf->Write(0, 'Email: ' . $email);
    $pdf->Ln();
    $pdf->Write(0, 'Identity Type: ' . $id_type);
    $pdf->Ln();
    $pdf->Write(0, 'Gender: ' . $gender);
    $pdf->Ln();
    $pdf->Write(0, 'Identity Number: ' . $id_card_no);
    $pdf->Ln();
    $pdf->Write(0, 'From Destination: ' . $from_dest);
    $pdf->Ln();
    $pdf->Write(0, 'To Destination: ' . $to_dest);
    $pdf->Ln();
    $pdf->Write(0, 'From Date: ' . $fromdate);
    $pdf->Ln();
    $pdf->Write(0, 'To Date: ' . $todate);
    $pdf->Ln();
    $pdf->Write(0, 'Cost: ' . $cost);
    $pdf->Ln();

    // Output PDF to a variable
    return $pdf->Output('', 'S');
}
?>
