
<?php
$servername = "localhost";
$username = "root"; 
$password = ""; 
$dbname = "buspass_db";
$mysqli = new mysqli("localhost", "root", "", "buspass_db");

// Function to retrieve all passes
function viewPasses() {
    global $mysqli;

    $passes = [];

    $sql = "SELECT * FROM tbluser";
    $result = $mysqli->query($sql);

    // Check if passes exist
    if ($result->num_rows > 0) {
        // Store passes in an array
        while ($row = $result->fetch_assoc()) {
            $passes[] = $row;
        }
    }

    return $passes;
}

// Function to retrieve pass details by ID
function getPassById($passId) {
    global $mysqli;

    
    $sql = "SELECT * FROM tbluser WHERE id = ?";
    $stmt = $mysqli->prepare($sql);
    $stmt->bind_param("i", $passId);
    $stmt->execute();
    $result = $stmt->get_result();
    $pass = $result->fetch_assoc();
    $stmt->close();

    return $pass;
}


// Function to accept a pass
function acceptPass($passId) {
    global $mysqli;

    // TODO: Update pass status to accepted in the database

    return "Pass accepted successfully.";
}


require_once "passdetail.php";

require_once "edit_pass.php";

require_once "accept_pass.php";

?>
