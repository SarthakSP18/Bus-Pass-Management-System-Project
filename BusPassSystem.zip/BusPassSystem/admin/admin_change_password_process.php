<?php
session_start();

// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "buspass_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $currentPassword = $_POST['current_password'];
    $newPassword = $_POST['new_password'];
    $confirmPassword = $_POST['confirm_password'];

    // Validate current password
    $adminUsername = $_SESSION['admin_username'];
    $sql = "SELECT password FROM admin WHERE username = '$adminUsername'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $hashedPassword = $row['password'];

        // Verify current password
        if (password_verify($currentPassword, $hashedPassword)) {
            // Validate new password
            if ($newPassword === $confirmPassword) {
                // Hash the new password
                $hashedNewPassword = password_hash($newPassword, PASSWORD_DEFAULT);

                // Update password in the database
                $updateSql = "UPDATE admin SET password = '$hashedNewPassword' WHERE username = '$adminUsername'";
                if ($conn->query($updateSql) === TRUE) {
                    // Password updated successfully
                    $message = "Password updated successfully.";
                    echo "<script>alert('$message');</script>";
                    echo "<script>setTimeout(function() { window.location.href = 'admindashboard.html'; }, 1500);</script>";

                } else {
                    // Error updating password
                    echo "Error updating password: " . $conn->error;
                }
            } else {
                // New password and confirm password do not match
                $error_message = "New password and confirm password do not match.";
                echo "<script>alert('$error_message');</script>";
            }
        } else {
            // Current password is incorrect
            $error_message = "Current password is incorrect.";
            echo "<script>alert('$error_message');</script>";
        }
    } else {
        // Admin not found
        $error_message = "Admin not found.";
        echo "<script>alert('$error_message');</script>";
    }
}

$conn->close();
?>
