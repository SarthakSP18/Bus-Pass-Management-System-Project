<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pass Requests</title>
    <style>
        /* CSS styles */
        table {
            width: 100%;
            border-collapse: collapse;
        }

        table th, table td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        table th {
            background-color: #f2f2f2;
        }

        table tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        table tr:hover {
            background-color: #ddd;
        }

        .img-container {
            width: 100px;
            height: 100px;
            overflow: hidden;
        }

        .img-container img {
            width: 100%;
            height: auto;
        }
    </style>
</head>
<body>

<?php
// Database connection
$servername = "localhost";
$username = "root"; 
$password = ""; 
$dbname = "buspass_db";

$mysqli = new mysqli($servername, $username, $password, $dbname);

if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

$sql = "SELECT * FROM tbluser";
$result = $mysqli->query($sql);

if ($result->num_rows > 0) {
    echo "<table>";
    echo "<tr><th>Pass Number</th><th>Full Name</th><th>Photo</th><th>Mobile Number</th><th>Identity Type</th><th>Id Number</th><th>From Date</th><th>To Date</th><th>Bonafide</th><th>Validity</th><th>FromDest</th><th>ToDest</th><th>Cost</th><th>Created At</th><th>Actions</th></tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row['passnumber'] . "</td>";
        echo "<td>" . $row['fullname'] . "</td>";
        echo "<td class='img-container'><img src='" . $row['photo'] . "' alt='User Photo'></td>";
        echo "<td>" . $row['phone_no'] . "</td>";
        echo "<td>" . $row['id_type'] . "</td>";
        echo "<td>" . $row['id_card_no'] . "</td>";
        echo "<td>" . $row['fromdate'] . "</td>";
        echo "<td>" . $row['todate'] . "</td>";
        echo "<td class='img-container'><img src='" . $row['bonafide'] . "' alt='User Bonafide'></td>";

        echo "<td>" . $row['validity'] . "</td>";
        echo "<td>" . $row['from_dest'] . "</td>";
        echo "<td>" . $row['to_dest'] . "</td>";
        echo "<td>" . $row['cost'] . "</td>";
        echo "<td>" . $row['created_at'] . "</td>";
        echo "<button class='viewButton' onclick='viewPass(" . $row['passnumber'] . ")'>View</button>";

        echo "<button class='acceptButton' data-pass-id='" . $row['passnumber'] . "'>Accept</button></td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "No passes found.";
}

$mysqli->close();
?>
</body>
</html>
