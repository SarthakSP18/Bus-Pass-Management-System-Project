<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Change Password</title>
    <link rel="stylesheet" href="adminlogin.css">
</head>
<body>
    <div class="login-container">
        <h2>Change Password</h2>
        <form action="admin_change_password_process.php" method="post">
            <div class="input-group">
                <label for="old-password">Old Password:</label>
                <input type="password" id="old-password" name="old-password" required>
            </div>
            <div class="input-group">
                <label for="new-password">New Password:</label>
                <input type="password" id="new-password" name="new-password" required>
            </div>
            <button type="submit">Change Password</button>
        </form>
    </div>
</body>
</html>
