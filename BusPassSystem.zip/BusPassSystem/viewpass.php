<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "buspass_db";

$mysqli = new mysqli($servername, $username, $password, $dbname);

if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

if (isset($_POST['passnumber'])) {
    $passnum = $_POST['passnumber'];

    $stmt = $mysqli->prepare("SELECT * FROM tbluser WHERE passnumber = ?");
    $stmt->bind_param("s", $passnum);

    $stmt->execute();

    // Get the result
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $passData = $result->fetch_assoc();

        $passDetails = array(
            'passFound' => true,
            'passnumber' => $passData['passnumber'],
            'fullname' => $passData['fullname'],
            'photo' => $passData['photo'],
            'phone_no'=> $passData['phone_no'],
            'email'=> $passData['email'],
            'id_type'=> $passData['id_type'],
            'id_card_no'=> $passData['id_card_no'],
            'fromdate'=> $passData['fromdate'],
            'todate'=> $passData['todate'],
            'from_dest'=> $passData['from_dest'],
            'to_dest'=> $passData['to_dest'],
            'cost'=> $passData['cost'],
            'created_at'=> $passData['created_at']   
        );

       
        echo json_encode($passDetails);
    } else {
        $passDetails = array('passFound' => false);
        echo json_encode($passDetails);
    }

    $stmt->close();
} else {
    echo "Pass number not provided.";
}

$mysqli->close();
?>
