<?php
// Database connection
$servername = "localhost";
$username = "root"; 
$password = ""; 
$dbname = "your_database_name";

// Create connection
$mysqli = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

// User ID for which to retrieve the pass PDF path
$userId = 123; // Replace with the actual user ID

// Query to fetch the pass PDF path for the user
$sql = "SELECT path_to_pass_pdf FROM users WHERE id = $userId";
$result = $mysqli->query($sql);

if ($result->num_rows > 0) {
    // Fetch the pass PDF path from the result
    $row = $result->fetch_assoc();
    $passPdfPath = $row['path_to_pass_pdf'];
    
    // Output the download link for the pass PDF
    echo "Pass PDF path for user with ID $userId: <a href='$passPdfPath' download>Download Pass</a>";
} else {
    echo "No pass PDF path found for user with ID $userId";
}

$mysqli->close();
?>
