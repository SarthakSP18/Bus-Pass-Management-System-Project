<?php
// Database connection
$servername = "localhost";
$username = "root"; 
$password = ""; 
$dbname = "buspass_db";

$mysqli = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

// Function to handle file uploads
function uploadFile($input_name, $target_dir) {
    if (isset($_FILES[$input_name]) && isset($_FILES[$input_name]["name"])) {
        $target_file = $target_dir . basename($_FILES[$input_name]["name"]);
        if (move_uploaded_file($_FILES[$input_name]["tmp_name"], $target_file)) {
            return $target_file;
        } else {
            return null; // Return null if file upload fails
        }
    } else {
        return null;
    }
}


$photo = uploadFile("photo", "images/");
$bonafide = uploadFile("bonafide", "images/");


if ($photo !== null) {
 
    $stmt = $mysqli->prepare("INSERT INTO tbluser (passnumber, fullname, photo, phone_no, gender, email, id_type, id_card_no, bonafide, validity, from_dest, to_dest, fromdate, todate, cost) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

   
    $stmt->bind_param("ssssssssssssssd", $passnum, $fullname, $photo, $phone_no, $gender, $email, $id_type, $id_card_no, $bonafide, $validity, $from_dest, $to_dest, $fromdate, $todate, $cost);

  
    $fullname = $_POST['fullname'];
    $phone_no = $_POST['phone_no'];
    $email = $_POST['email'];
    $gender = $_POST['gender'];
    $id_type = $_POST['identitytype'];
    $id_card_no = $_POST['icnum'];
    $from_dest = $_POST['from_dest'];
    $to_dest = $_POST['to_dest'];
    $validity = $_POST['validity'];
    $fromdate = $_POST['fromdate'];
    $todate = $_POST['todate'];
    $cost = $_POST['cost'];
    $passnum = mt_rand(100000000, 999999999);

    
    if ($stmt->execute()) {
       
        $message = "Admin is Verifying your Documents please wait few seconds & Re-login .";
        echo "<script>alert('$message');</script>";
        echo "<script>setTimeout(function() { window.location.href = 'home_page.html'; }, 2000);</script>";
    } else {
        
        echo "Error: " . $mysqli->error;
    }

   
    $stmt->close();
} else {
   
    echo "Error: Photo upload failed.";
}


$mysqli->close();
?>
