// admin_dashboard.js
$(document).ready(function() {
    // Load pass list on page load
    $.ajax({
        type: 'GET',
        url: 'load_pass_list.php', // Implement this PHP script to load pass list
        success: function(passList) {
            $('#passList').html(passList);
        }
    });

    // Handle accept button click
    $(document).on('click', '.acceptButton', function() {
        var passId = $(this).data('pass-id');
        // Send pass acceptance request to server using AJAX
        $.ajax({
            type: 'POST',
            url: 'accept_pass.php', // Implement this PHP script to accept pass
            data: { passId: passId },
            success: function(response) {
                alert(response); // Display response message
                // Reload pass list after acceptance
                $.ajax({
                    type: 'GET',
                    url: 'load_pass_list.php',
                    success: function(passList) {
                        $('#passList').html(passList);
                    }
                });
            }
        });
    });
});