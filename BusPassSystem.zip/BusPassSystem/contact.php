<!-- <form action="submit_contact.php" method="post">
    <input type="text" name="name" placeholder="Your Name" required><br>
    <input type="email" name="email" placeholder="Your Email" required><br>
    <input type="text" name="subject" placeholder="Subject" required><br>
    <textarea name="message" placeholder="Your Message" required></textarea><br>
    <button type="submit">Submit</button>
</form> -->
