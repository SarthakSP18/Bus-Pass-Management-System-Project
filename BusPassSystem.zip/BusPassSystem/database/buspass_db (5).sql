-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 15, 2024 at 12:48 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `buspass_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `username`, `password`) VALUES
(1, 'admin', '$2y$10$.kTCpgvyl.QGUJqoirb1EOBe9xdZEUDUg94bmoQEJ4bmCV67qh0zq');

-- --------------------------------------------------------

--
-- Table structure for table `tbluser`
--

CREATE TABLE `tbluser` (
  `id` int(20) NOT NULL,
  `passnumber` varchar(50) NOT NULL,
  `fullname` varchar(50) NOT NULL,
  `photo` varchar(250) NOT NULL,
  `phone_no` varchar(20) NOT NULL,
  `gender` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `id_type` varchar(20) NOT NULL,
  `id_card_no` varchar(20) NOT NULL,
  `bonafide` varchar(250) NOT NULL,
  `fromdate` date NOT NULL,
  `todate` date NOT NULL,
  `validity` varchar(20) NOT NULL,
  `from_dest` varchar(50) CHARACTER SET utf16 COLLATE utf16_unicode_ci NOT NULL,
  `to_dest` varchar(50) NOT NULL,
  `cost` decimal(10,2) NOT NULL,
  `created_at` timestamp(6) NOT NULL DEFAULT current_timestamp(6),
  `pass_status` varchar(50) NOT NULL DEFAULT 'Pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbluser`
--

INSERT INTO `tbluser` (`id`, `passnumber`, `fullname`, `photo`, `phone_no`, `gender`, `email`, `id_type`, `id_card_no`, `bonafide`, `fromdate`, `todate`, `validity`, `from_dest`, `to_dest`, `cost`, `created_at`, `pass_status`) VALUES
(12, '408148194', 'chhaya sadhu pomane', 'images/1337462.png', '9370334565', 'female', 'chhaya@gmail.com', 'Student Card', '2123', 'images/64k-ultra-hd-hacker-anonymous-neon-mask-cyjce15sg57sfjsn.jpg', '2024-04-07', '2024-05-07', 'valid', 'Baramati Rural', 'Rui', 500.00, '2024-04-07 08:59:04.081474', 'Accepted'),
(13, '824262137', 'sp sp', 'E:/xampp/htdocs/BusPassSystem/images/Picsart_24-01-26_22-34-40-150.jpg', '1172860380', 'male', 'sarthakpomane123@gmail.com', 'Student Card', '3443', 'E:/xampp/htdocs/BusPassSystem/images/scannerfinal.jpeg', '2024-04-07', '2024-05-07', 'valid', 'Ambi Bk', 'Anjangaon', 780.00, '2024-04-07 09:16:15.604550', 'Accepted'),
(14, '387343307', 'tatya vinchu', 'E:/xampp/htdocs/BusPassSystem/images/WhatsApp Image 2024-04-05 at 12.06.05 PM.jpeg', '1234512345', 'male', 'tatyavinchu@gmail.com', 'Student Card', '234', 'E:/xampp/htdocs/BusPassSystem/images/WhatsApp Image 2024-04-05 at 12.06.06 PM.jpeg', '2024-04-07', '2024-05-07', 'valid', 'Bhondvewadi', 'Ambi Bk', 500.00, '2024-04-07 09:19:47.324644', 'Accepted'),
(15, '302109175', 'manya bhai', 'images/Moonlight-Japanese-Painting-AI-Generated-4K-Wallpaper.jpg', '12341234', 'male', 'manya@gmail.com', 'Student Card', '1213', 'images/cyberpunk-naruto-rainy-street-thumb.jpg', '2024-04-07', '2024-05-07', 'valid', 'Dhumalwadi', 'Ambi Bk', 500.00, '2024-04-07 09:24:07.931393', 'Accepted'),
(16, '511762023', 'samarth vikas raut', 'images/WhatsApp Image 2024-04-05 at 12.06.05 PM.jpeg', '9322639998', 'male', 'samya@gmail.com', 'Student Card', '9652', 'images/scannerfinal.jpeg', '2024-04-07', '2024-05-08', 'valid', 'Rui', 'Morgaon', 500.00, '2024-04-07 15:45:46.569325', 'Accepted'),
(17, '156254549', 'Sarthak Sadhu Pomane', 'images/scannerfinal.jpeg', '9172860380', 'male', 'sarthakpomane123@gmail.com', 'Student Card', '1212', 'images/wp7040905.jpg', '2024-04-15', '2024-05-15', 'Monthly', 'Rui', 'Sayambachiwadi', 1070.00, '2024-04-15 10:38:35.758188', 'Accepted');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `path_to_pass_pdf` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `password`, `created_at`, `path_to_pass_pdf`) VALUES
(23, 'abhijeet satav', '$2y$10$ZXMafGRwSHETtd8fhcGrfuJjnfwNuYMq6Vl5J/IxuWqkSWLyIJuNW', '2024-03-27 18:09:45', ''),
(28, 'sarthak pomane', '$2y$10$p0C5Rd/MO4B6IiZyRNHKwOWj55zbWHZyRKEhwb/8xYO2dM4WFTVCG', '2024-03-28 00:38:11', ''),
(30, 'admin', '$2y$10$aA57UhTs4RFFwsJmpvCevORkZiCI7SnUYTut8hmnE8N37LBQQbmVe', '2024-03-28 00:57:42', ''),
(31, 'admin bhau', '$2y$10$z5POFtQhDqJ5C9WC7WTDwO7DK/ar4Sd9FanVQhQAfIkAvXDiMMHg2', '2024-03-28 01:02:47', ''),
(34, 'sarthak', '$2y$10$.S.QDjHB892Hy0j7rZlOG.lkw4FF3jdKMciNwnittROLE8FVib5Eu', '2024-03-28 13:36:51', ''),
(35, 'sp', '$2y$10$E2itYO/BzZLiSv4tbZYLPOUaU1CKxb88B4OJnPDe9oWFJjo.wBix6', '2024-04-02 22:47:15', ''),
(36, 'virat kohli', '$2y$10$zLVrpoGjelP5slEA6peiqeJl9PUzjroRZEFWKx5NkzxKnHS1fKnYK', '2024-04-03 00:17:34', ''),
(37, 'sarthak pomane', '$2y$10$Bp0hs3cweTofVAfKNTpjc.CXxdXR1MFTMA22JivK9DXY3Uv1neZkm', '2024-04-05 12:03:18', ''),
(38, 'weo weo', '$2y$10$SKHjGgp4net3WMWkbyx7SeJ3G/Rl9.SPX5Yq1sKE3ELIYu8OnDgfq', '2024-04-06 09:25:07', ''),
(39, 'gojo satoru', '$2y$10$aTCR9XL.QoEk4bSfQ2aiSeHJfladNJPTCpkikP0ZzO99ezZITiwG.', '2024-04-06 09:33:44', ''),
(40, 'abhi', '$2y$10$jyGq5LsIMceWKREQihTdnucYWaUsR5qbr/RluX5iN2eJn5E5p3St6', '2024-04-06 10:39:59', ''),
(41, 'abhi satav', '$2y$10$E8ZXVzAXPY2TvaaW1i07H.Q1syL7Q9aEUicLH4bmGMWaNaXKXqJzS', '2024-04-06 12:09:23', ''),
(42, 'abhi pakhale', '$2y$10$8jceOckaSJD1icLer23VVOIyVser2KMNV34LdWZakHYXlqKezF29a', '2024-04-06 12:16:28', ''),
(43, 'krishna mulik', '$2y$10$YVbDrrexp4U.1m2eC3Tqx.xUt0HtaMMOe66SVea/ZD31kmpvOJeFK', '2024-04-06 12:28:38', ''),
(44, 'krishna mulika', '$2y$10$2TsiY4wUrTePZj8CLMRZEetJi.eWlk..Kn.qGhHQFv5TcKqL5t7DG', '2024-04-06 14:38:12', ''),
(45, 'sarthak sadhu pomane', '$2y$10$zDhUAL/Iam0m.mE2liCvmOzYw03OWF8HPKCmNgPHdP6YGMqOKtt/O', '2024-04-07 13:49:32', ''),
(46, 'sarthak pomane', '$2y$10$ssY8FJcW2tCP88auqYrS0OqywGLVhADdxbQkP0ssjbeBpy9kdd74m', '2024-04-07 13:54:36', ''),
(47, 'chhaya pomane', '$2y$10$BLnOdVe8JI/zVnaoN3tYrebSB07V2ZWe9qTQYlPU/Gb43GtDM08Ma', '2024-04-07 14:24:04', ''),
(48, 'sp', '$2y$10$lHLlXZdbK8asEi6cctDj2uM6lnc6C3H7fKrazo6pEDYXeg950rebS', '2024-04-07 14:44:34', ''),
(49, 'dogesh', '$2y$10$ecIKuRVrPuoW2wLZeCLKhO5CwqWRc3X/FLqNfEsgtAO3CCep9dD7G', '2024-04-07 14:48:22', ''),
(50, 'manya', '$2y$10$yuYjK1fW3alcxR9eneRzVuxIZ3.cbEgORIqcGMo7Xb0lOzZ8EpFT6', '2024-04-07 14:52:50', ''),
(51, 'samya raut', '$2y$10$4UOcgy1eNfxq7OSb6fsq0ea4NLqGKILcGiBD3nI8EKgcNSgASiutq', '2024-04-07 21:09:09', ''),
(52, 'abhijeet satav', '$2y$10$G2bP4rfDNQvPoYvJMEOez.9COKi59di6/ddL4rZ4SeAVGtyD1VFxu', '2024-04-15 13:39:11', ''),
(53, 'sarthak pomane', '$2y$10$WUawgrIXSIMygc3Hp6lFleTym06hGefiavw7Q56yatfHDq.8.0W3m', '2024-04-15 15:58:00', ''),
(54, 'sarthak pomane', '$2y$10$EsYjtBM/6OjVNlr/8FAIv.C/d..GM/j90knfN5QzFYBzbU851W7wC', '2024-04-15 16:10:44', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `tbluser`
--
ALTER TABLE `tbluser`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbluser`
--
ALTER TABLE `tbluser`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
