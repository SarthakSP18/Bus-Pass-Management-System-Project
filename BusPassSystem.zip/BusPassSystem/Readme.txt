	
***********************************************************
	Step 1: Create Database name : buspass_db.
	Step 2: Extract BusPassSystem in Xampp Htdocs.
	Step 3: Import Database file(buspass_db(5).sql) in buspass_db .
	Step 4: Run BusPassSystem.

	****	How It Works:	****

	Step 5: User Creates Account then Submit Details and Request for Pass
	Step 6: Admin Logins and Accept his/her request
	Step 7: User Logins and Search his/her Submitted Valid phone number and Search
	Step 8: Download Pass & Print 



**********************************************************