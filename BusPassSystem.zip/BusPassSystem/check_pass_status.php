<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "buspass_db";

$mysqli = new mysqli($servername, $username, $password, $dbname);

// Check for database connection errors
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

if (isset($_GET['phone'])) {
    $phone = $_GET['phone'];

    $sql = "SELECT * FROM tbluser WHERE phone_no = ?";
    $stmt = $mysqli->prepare($sql);
    $stmt->bind_param("s", $phone);

    if ($stmt->execute()) {
        $result = $stmt->get_result();
        if ($result->num_rows > 0) {
            // Pass is generated for the user
            $row = $result->fetch_assoc();
            // Display pass structure with photo
            echo "<div class='pass'>";
            echo "<img src='uploads/" . $row['photo'] . "' alt='Pass Photo'>";
            echo "<button onclick='downloadPass()'>Download Pass</button>";
            echo "</div>";
        } else {
            $message = "Your pass is not generated yet. Please wait for the admin to process your request.";
            echo "<script>alert('$message');</script>";
            echo "<script>setTimeout(function() { window.location.href = 'user_dashboard.html'; }, 1000);</script>";
        }
    } else {
        // Error executing the query
        echo "Failed to check pass status: " . $stmt->error;
    }

    // Close the prepared statement
    $stmt->close();
} else {
    
    echo "Phone number not provided.";
}

// Close the database connection
$mysqli->close();
?>
