<?php
// Database connection
$host = "localhost";
$username = "root";
$password = "";
$database = "buspass_db";

$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Hash the password
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Sanitize user input to prevent SQL injection
    $username = mysqli_real_escape_string($conn, $username);

    // Query to insert user into database
    $query = "INSERT INTO users (username, password) VALUES ('$username', '$hashed_password')";

    if ($conn->query($query) === TRUE) {
        $message = "User Registered Successfully.";
            echo "<script>alert('$message');</script>";
            echo "<script>setTimeout(function() { window.location.href = 'pass.html'; }, 1000);</script>";
            
        
        
    } else {
        // Check if the error is due to a duplicate entry for the primary key
        if ($conn->errno == 1062) {
            echo "Error: Duplicate entry. This username is already taken.";
        } else {
            echo "Error: " . $query . "<br>" . $conn->error;
        }
    }
}
?>
