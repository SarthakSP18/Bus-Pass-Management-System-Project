<?php
$name = $_POST['name'];
$email = $_POST['email'];
$subject = $_POST['subject'];
$message = $_POST['message'];

$to = 'sarthakpomane123@gmail.com'; // Admin's email address
$headers = "From: $name <$email>" . "\r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-type: text/html; charset=iso-8859-1\r\n";

$smtpHost = 'smtp.gmail.com';
$smtpPort = 587; // SMTP port (TLS)

// Enable TLS encryption
$smtpConfig = [
    'ssl' => [
        'verify_peer' => false,
        'verify_peer_name' => false,
        'allow_self_signed' => true
    ],
    'tls' => [
        'verify_peer' => false,
        'verify_peer_name' => false,
        'allow_self_signed' => true
    ]
];

if (mail($to, $subject, $message, $headers, '-f' . $email)) {
    $message = "Contact request submitted successfully";
    echo "<script>alert('$message');</script>";
    echo "<script>setTimeout(function() { window.location.href = 'home_page.html'; }, 1000);</script>";
   
} else {
    $message = "Contact request submitted successfully!";
    echo "<script>alert('$message');</script>";
    echo "<script>setTimeout(function() { window.location.href = 'home_page.html'; }, 1);</script>";
}
?>
