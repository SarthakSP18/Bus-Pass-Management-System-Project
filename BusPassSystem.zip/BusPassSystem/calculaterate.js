document.addEventListener("DOMContentLoaded", function() {
    var fromSelect = document.getElementById('from');
    var toSelect = document.getElementById('to');
    fromSelect.addEventListener('change', updateCost);
    toSelect.addEventListener('change', updateCost);

    function updateCost() {
        var from = fromSelect.value;
        var to = toSelect.value;


        var cost = calculateCost(from, to);

        var costInput = document.getElementById('cost');
        costInput.value = cost;
    }

    function calculateCost(from, to) {

        if (from === 'Ambi Bk' && to === 'Anjangaon') {
            return '780';
        } else if (from === 'Anjangaon' && to === 'Baburdi') {
            return '520';
        } else if (from === 'Baburdi' && to === 'Bajrangwadi') {
            return '580';
        } else if (from === 'Baramati Rural' && to === 'Barhanpur') {
            return '220';
        } else if (from === 'Bhondvewadi' && to === 'Chandgude Wadi') {
            return '720';
        } else if (from === 'Chandgude Wadi' && to === 'Chaudhar Wadi') {
            return '700';
        } else if (from === 'Dandwadi' && to === 'Deulgaon Rasal') {
            return '280';
        } else if (from === 'Deulgaon Rasal' && to === 'Deulwadi') {
            return '680';
        } else if (from === 'Dhumalwadi' && to === 'Dorlewadi') {
            return '520';
        } else if (from === 'Ghadagewadi' && to === 'Gojubavi') {
            return '560';
        } else if (from === 'Gunwadi' && to === 'Jainakwadi') {
            return '440';
        } else if (from === 'Jalgaon Kade Pathar' && to === 'Jalgaon Supe') {
            return '560';
        } else if (from === 'Jalgaon N/A' && to === 'Kamagalwadi') {
            return '800';
        } else if (from === 'Kambleshwar' && to === 'Kanheri') {
            return '740';
        } else if (from === 'Kanheri' && to === 'Karanjepul') {
            return '1160';
        } else if (from === 'Karanjepul' && to === 'Karhavagaj') {
            return '1030';
        } else if (from === 'Katewadi' && to === 'Katphal') {
            return '610';
        } else if (from === 'Magarwadi' && to === 'Malad') {
            return '1090';
        } else if (from === 'Malad' && to === 'Malegaon') {
            return '280';
        } else if (from === 'Malegaon' && to === 'Masalwadi') {
            return '320';
        } else if (from === 'Masalwadi' && to === 'Mekhali') {
            return '1440';
        } else if (from === 'Mekhali' && to === 'Morgaon') {
            return '320';
        } else if (from === 'Morgaon' && to === 'Mudhale') {
            return '580';
        } else if (from === 'Mudhale' && to === 'Nimbodi') {
            return '1480';
        } else if (from === 'Nimbodi' && to === 'Pandharwadi') {
            return '1380';
        } else if (from === 'Pandahrwadi' && to === 'Parwadi') {
            return '3040';
        } else if (from === 'Parwadi' && to === 'Pimpali') {
            return '3500';
        } else if (from === 'Pimpali' && to === 'Rui') {
            return '190';
        } else if (from === 'Rui' && to === 'Sabalewadi') {
            return '3580';
        } else if (from === 'Sabalewadi' && to === 'Sangavi') {
            return '3840';
        } else if (from === 'Sangavi' && to === 'Sawal') {
            return '740';
        } else if (from === 'Sawal' && to === 'Sawantwadi') {
            return '448';
        } else if (from === 'Sawantwadi' && to === 'Sayambachiwadi') {
            return '800';
        } else if (from === 'Sayambachiwadi' && to === 'Shirawali') {
            return '990';
        } else if (from === 'Shirawali' && to === 'Shirsuphal') {
            return '1160';
        } else if (from === 'Shirsuphal' && to === 'Songaon') {
            return '1280';
        } else if (from === 'Songaon' && to === 'Tandulwadi') {
            return '600';
        } else if (from === 'Tandulwadi' && to === 'vanjarwadi') {
            return '210';
        } else if (from === 'vanjarwadi' && to === 'Zhargadwadi') {
            return '480';
        } else if (from === 'Zhargadwadi' && to === 'Baramati Rural') {
            return '496';
        } else if (from === 'Baburdi' && to === 'Rui') {
            return '1090';
        } else if (from === 'Baburdi' && to === 'Morgaon') {
            return '240';
        } else if (from === 'Rui' && to === 'Rui') {

            return '0';
        } else if (from === 'Rui' && to === 'Morgaon') {
            return '1280';
        } else if (from === 'Rui' && to === 'Mekhali') {
            return '610';
        } else if (from === 'Rui' && to === 'Baramati Rural') {
            return '464';
        } else if (from === 'Rui' && to === 'Sayambachiwadi') {
            return '1070';
        } else {

            return '760';
        }
    }
});